"""
混淆器模块初始化文件
"""
from .obfuscator import Obfuscator, ObfuscationRule

__all__ = ['Obfuscator', 'ObfuscationRule']
